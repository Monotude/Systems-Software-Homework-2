/* $Id: lexer.c,v 1.14 2023/10/06 07:56:47 leavens Exp $ */

#include "lexer.h"

// All the functions declared in lexer.h are
// defined in the user code section of pl0_lexer.l
// These can be copied to pl0_lexer.l (after the last %%)
// from the file pl0_lexer_user_code.c, if desired.
